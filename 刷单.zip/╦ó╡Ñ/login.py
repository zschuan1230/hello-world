#coding=utf-8
import time
from selenium.webdriver.common.action_chains import ActionChains

def login(driver, usrename, password):
    # 点击登录按钮
    driver.find_element_by_xpath('//*[@id="searchFixed"]/div[2]/div[1]/a[3]').click()
    time.sleep(3)
    # 点击账号密码登录
    driver.find_element_by_xpath('/html/body/div[1]/div[6]/a[2]').click()
    # 输入用户名
    driver.find_element_by_xpath('//*[@id="username"]').send_keys('17626022721')
    time.sleep(1)
    # 输入密码
    driver.find_element_by_xpath('//*[@id="password"]').send_keys('zsc17626022721')
    time.sleep(1)


def verify_code(driver):
    # 获取滑块的元素
    ele = driver.find_element_by_xpath('//*[@id="siller2_dt_child_content_containor"]/div[3]')
    # ele.
